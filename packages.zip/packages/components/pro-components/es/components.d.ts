declare const _default: {
    ProButton: any;
};
export default _default;
