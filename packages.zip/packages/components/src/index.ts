import "element-plus/theme-chalk/index.css";
// export * from "@element-plus/pro-tabs";
// export * from "@element-plus/pro-form";
// export * from "@element-plus/pro-table";
// export * from "@element-plus/pro-radio";
export * from "@element-plus/pro-button";
// export * from "@element-plus/pro-search-bar";