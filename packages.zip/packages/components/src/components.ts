//import ProTabs from "@element-plus/pro-tabs";
// import ProForm from "@element-plus/pro-form";
// import ProTable from "@element-plus/pro-table";
// import ProRadio from "@element-plus/pro-radio";
import ProButton from "@element-plus/pro-button";
// import ProSearchBar from "@element-plus/pro-search-bar";

export default {
    // ProTabs,
    // ProForm,
    // ProTable,
    // ProRadio,
    ProButton,
    // ProSearchBar
}