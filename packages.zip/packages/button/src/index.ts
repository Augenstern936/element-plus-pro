import ProButton from "./Button";
import { ProButtonProps } from "./typing";

export {
    ProButton
}

export type {
    ProButtonProps
}

export default ProButton;